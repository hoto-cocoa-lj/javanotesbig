package [package].biz;
import [package].entity.[Table];
/**
 * [comment]业务逻辑层接口
 * @author Administrator
 *
 */
public interface I[Table]Biz extends IBaseBiz<[Table]>{
	
	
}

